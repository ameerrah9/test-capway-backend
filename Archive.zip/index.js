const https = require('https');

https.get('https://newsapi.org/v2/top-headlines?country=us&apiKey=c3fbfbd05f614d19a3f93b8bdebf77a3', (resp) => {
  let data = '';

  // A chunk of data has been received.
  resp.on('data', (chunk) => {
    data += chunk;
  });

  // The whole response has been received. Print out the result.
  resp.on('end', () => {
    console.log(JSON.parse(data));
  });

}).on("error", (err) => {
  console.log("Error: " + err.message);
});